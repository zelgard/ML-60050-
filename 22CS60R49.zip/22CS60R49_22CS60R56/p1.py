#!/usr/bin/env python
# coding: utf-8

# # Importing Libraries

# In[290]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random


# In[291]:


df = pd.read_csv("Train_D_Tree.csv")


# In[292]:


# encoding yes/no categorial data
df['Extra Cheeze'].replace(['yes','no'],[1,0],inplace=True)
df['Extra Mushroom'].replace(['yes','no'],[1,0],inplace=True)
df['Extra Spicy'].replace(['yes','no'],[1,0],inplace=True)
df.drop(['Restaurant'],axis=1,inplace=True)


# # EDA

# In[293]:


df['Extra Spicy'].value_counts().plot.bar(color='red')
plt.xlabel("Categories")
plt.ylabel("Count")



# In[294]:


df['Extra Cheeze'].value_counts().plot.bar(color='green')
plt.xlabel("Categories")
plt.ylabel("Count")



# In[295]:


df['Extra Mushroom'].value_counts().plot.bar()
plt.xlabel("Categories")
plt.ylabel("Count")



# In[296]:


df.plot(x=2,y=4,kind='bar')


# 
# # SUM OF SQUARE ERROR FUNCTION

# In[297]:


#sum square error for the model
def sum_square_error(Y_test, Y_pred):
    error = 0
    mean_sample = np.mean(Y_test)
    for i in range(len(Y_test)):
        error = error + (Y_pred[i] - mean_sample)**2
    return error


# # TRAIN_TEST SPLIT FUNCTION

# In[298]:


def train_test_split(df, test_size):
    test_size = round(len(df) * test_size)
    indices = df.index.tolist()
    test_indices = random.sample(population = indices, k = test_size)
    test_df = df.loc[test_indices]
    train_df = df.drop(test_indices)
    
    return train_df,test_df


# In[299]:





# # TRAIN_TEST SPLIT

# In[300]:


random.seed(41)
train_df,test_df=train_test_split(df,0.3)
height_list = []
rmse_list = []
print(len(train_df))
print(len(test_df))

# # TREE NODE

# In[301]:


class Node():
    def __init__(self, feature_index=None, threshold=None, left=None, right=None, var_red=None, value=None):
        ''' constructor ''' 
        
        # for decision node
        self.feature_index = feature_index
        self.threshold = threshold
        self.left = left
        self.right = right
        self.var_red = var_red
        
        # for leaf node
        self.value = value


# # DECISION TREE REGRESSOR

# In[302]:


class DecisionTreeRegressor():
    def __init__(self):
        ''' constructor '''
        # initialize the root of the tree 
        self.root = None
        
        
    def build_tree(self, dataset):
        ''' recursive function to build the tree '''
        
        X, Y = dataset[:,:-1], dataset[:,-1]
        num_samples, num_features = np.shape(X)
        best_split = {}
        # find the best split
        best_split = self.get_best_split(dataset, num_samples, num_features)
        # check if information gain is positive
        if best_split["var_red"]>0:
            # recur left
            left_subtree = self.build_tree(best_split["dataset_left"])
            # recur right
            right_subtree = self.build_tree(best_split["dataset_right"])
            # return decision node
            return Node(best_split["feature_index"], best_split["threshold"], 
                       left_subtree, right_subtree, best_split["var_red"])
        
        # compute leaf node
        leaf_value = self.calculate_leaf_value(Y)
        # return leaf node
        return Node(value=leaf_value)
    
    def build_tree_pruning(self, dataset, max_depth, curr_depth=0):
        ''' recursive function to build the tree '''
        
        X, Y = dataset[:,:-1], dataset[:,-1]
        num_samples, num_features = np.shape(X)
        best_split = {}
        # split until stopping condition is met
        if curr_depth<=max_depth:
            # find the best split
            best_split = self.get_best_split(dataset, num_samples, num_features)
            # check if information gain is positive
            if best_split["var_red"]>0:
                # recur left
                left_subtree = self.build_tree_pruning(best_split["dataset_left"], curr_depth+1)
                # recur right
                right_subtree = self.build_tree_pruning(best_split["dataset_right"], curr_depth+1)
                # return decision node
                return Node(best_split["feature_index"], best_split["threshold"], 
                            left_subtree, right_subtree, best_split["var_red"])
        
        # compute leaf node
        leaf_value = self.calculate_leaf_value(Y)
        # return leaf node
        return Node(value=leaf_value)
    
    def get_best_split(self, dataset, num_samples, num_features):
        ''' function to find the best split '''
        
        # dictionary to store the best split
        best_split = {}
        max_var_red = -float("inf")
        # loop over all the features
        for feature_index in range(num_features):
            feature_values = dataset[:, feature_index]
            possible_thresholds = np.unique(feature_values)
            # loop over all the feature values present in the data
            for threshold in possible_thresholds:
                # get current split
                if feature_index == 2:
                    dataset_left, dataset_right = self.split_size(dataset, feature_index, threshold)
                else:
                    dataset_left, dataset_right = self.split(dataset, feature_index, threshold)

                if len(dataset_left)>0 or len(dataset_right)>0:
                    if len(dataset_left)==0:
                        y, right_y = dataset[:,-1], dataset_right[:, -1]
                        weight_r = len(right_y) / len(y)
                        curr_var_red = np.var(y) - (weight_r * np.var(right_y))
                    elif len(dataset_right)==0:
                        y, left_y = dataset[:,-1], dataset_left[:, -1]
                        weight_l = len(left_y) / len(y)
                        curr_var_red = np.var(y) - (weight_l * np.var(left_y))
                    else:
                        y, left_y, right_y = dataset[:, -1], dataset_left[:, -1], dataset_right[:, -1]
                        # compute information gain
                        curr_var_red = self.variance_reduction(y, left_y, right_y)
                    # update the best split if needed
                    if curr_var_red>max_var_red:
                        best_split["feature_index"] = feature_index
                        best_split["threshold"] = threshold
                        best_split["dataset_left"] = dataset_left
                        best_split["dataset_right"] = dataset_right
                        best_split["var_red"] = curr_var_red
                        max_var_red = curr_var_red
                        
        # return best split
        return best_split
    
    def split_size(self, dataset, feature_index, threshold):
        ''' function to split the data '''
        
        dataset_left = np.array([row for row in dataset if row[feature_index]<=threshold])
        dataset_right = np.array([row for row in dataset if row[feature_index]>threshold])
        return dataset_left, dataset_right
    
    def split(self, dataset, feature_index, threshold):
        dataset_left = np.array([row for row in dataset if row[feature_index]==threshold])
        dataset_right = np.array([row for row in dataset if row[feature_index]!=threshold])
        return dataset_left, dataset_right
    
    def variance_reduction(self, parent, l_child, r_child):
        ''' function to compute variance reduction '''
        
        weight_l = len(l_child) / len(parent)
        weight_r = len(r_child) / len(parent)
        reduction = np.var(parent) - (weight_l * np.var(l_child) + weight_r * np.var(r_child))
        return reduction
    
    def calculate_leaf_value(self, Y):
        ''' function to compute leaf node '''
        
        val = np.mean(Y)
        return val
                
    def print_tree(self, tree=None, indent=" "):
        ''' function to print the tree '''
        
        if not tree:
            tree = self.root

        if tree.value is not None:
            print(tree.value)

        else:
            print("X_"+str(tree.feature_index), "<=", tree.threshold, "?", tree.var_red)
            print("%sleft:" % (indent), end="")
            self.print_tree(tree.left, indent + indent)
            print("%sright:" % (indent), end="")
            self.print_tree(tree.right, indent + indent)
    
    def fit(self, X, Y):
        ''' function to train the tree '''
        
        dataset = np.concatenate((X, Y), axis=1)
        self.root = self.build_tree(dataset)
        
    def fit_pruning(self, X, Y, max_depth):
        dataset = np.concatenate((X, Y), axis=1)
        node = self.build_tree_pruning(dataset,max_depth)
        return node
        
    def make_prediction(self, x, tree):
        ''' function to predict new dataset '''
        
        if tree.value!=None: return tree.value
        feature_val = x[tree.feature_index]
        if tree.feature_index == 2:
            if feature_val<=tree.threshold:
                return self.make_prediction(x, tree.left)
            else:
                return self.make_prediction(x, tree.right)
        else:
            if feature_val==tree.threshold:
                return self.make_prediction(x, tree.left)
            else:
                return self.make_prediction(x, tree.right)
    
    def predict(self, X):
        ''' function to predict a single data point '''
        
        preditions = [self.make_prediction(x, self.root) for x in X]
        return preditions
    
    def predict_pruning(self, X, node):
        predictions = [self.make_prediction(x,node) for x in X]
        return predictions
    
    def height(self, tree=None):
        '''function to calculate the decision tree height'''
        
        if not tree:
            tree = self.root
        if tree.left == None and tree.right == None:
            return 1
        elif tree.left == None:
            return 1 + self.height(tree.right)
        elif tree.right == None:
            return 1 + self.height(tree.left)
        else:
            l_height = self.height(tree.left)
            r_height = self.height(tree.right)
            return 1 + max(l_height,r_height)
        
    def post_pruning(self, X, Y, X_test, Y_test, height):
        print(height)
        node = self.fit_pruning(X,Y,height) 
        Y_pred = self.predict_pruning(X_test, node)
        min_error = sum_square_error(Y_test,Y_pred)
        perfect_height = height
        rmse_list.append(min_error)
        for i in range(2,height):
            #height_list.append(i)
            node1 = self.fit_pruning(X,Y,i)
            Y_pred = self.predict_pruning(X_test, node1)
            error = sum_square_error(Y_test,Y_pred)
            rmse_list.append(error)
            if(error < min_error):
                node = node1
                min_error = error
                perfect_height = height
        print(perfect_height)
        print(min_error)
        return node
print(height_list)


# # SPLITTING INTO FEATURE AND TARGET VALUE

# In[303]:


X=train_df.iloc[:,:-1].values
Y=train_df.iloc[:,-1].values.reshape(-1,1)
print(len(X))
print(Y)


# # CREATING AN  DECISION TREE REGRESSOR OBJECT AND FITTING THE MODEL

# In[304]:


regressor=DecisionTreeRegressor()
regressor.fit(X,Y)
regressor.print_tree()
regressor.height()


# # TESTING AND PREDICTING

# In[305]:


X_test = test_df.iloc[:, :-1].values
Y_test = test_df.iloc[:, -1].values.reshape(-1,1)
Y_pred = regressor.predict(X_test)


# # REPEATING THE ABOVE STEPS FOR 10 DIFFERENT SPLITS

# In[306]:


#iterating over 10 random train-test dataset splits and taking the best out of it to train the model

train_df, test_df = train_test_split(df,0.3)

regressor = DecisionTreeRegressor()
X = train_df.iloc[:, :-1].values
Y = train_df.iloc[:, -1].values.reshape(-1,1)
regressor.fit(X,Y)

X_test = test_df.iloc[:, :-1].values
Y_test = test_df.iloc[:, -1].values.reshape(-1,1)
Y_pred = regressor.predict(X_test)

min_error = sum_square_error(Y_test,Y_pred)
tree_height = regressor.height()

for i in range(10):
    temp_train_df, temp_test_df = train_test_split(df,0.3)
    temp_regressor = DecisionTreeRegressor()
    temp_X = temp_train_df.iloc[:, :-1].values
    temp_Y = temp_train_df.iloc[:, -1].values.reshape(-1,1)
    temp_regressor.fit(temp_X,temp_Y)
    temp_X_test = temp_test_df.iloc[:, :-1].values
    temp_Y_test = temp_test_df.iloc[:, -1].values.reshape(-1,1)
    temp_Y_pred = temp_regressor.predict(X_test)
    error = sum_square_error(temp_Y_test,temp_Y_pred)
    
    if error < min_error:
        min_error = error
        train_df = temp_train_df
        test_df = temp_test_df
        tree_height = temp_regressor.height()
        regressor = temp_regressor
        Y_pred = temp_Y_pred
    height_list.append(tree_height)
    rmse_list.append(min_error)
regressor.print_tree()
print(min_error)


# In[307]:


np.array(height_list)


# # CALCULATING RMSE SCORE

# In[308]:


SSE=np.array(rmse_list)
MSE=SSE/len(rmse_list)
RSE=np.sqrt(MSE)


# In[309]:



final_df=pd.DataFrame([height_list,RSE])
final_df=final_df.T


# In[310]:

import random


# In[291]:


final_df


# In[311]:


final_df.dropna()


# In[312]:


print(len(height_list))
print(len(rmse_list))


# # PLOTTING GRAPH BETWEEN DEPTH OF TREE vs RMSE

# In[313]:


final_df.plot(x=0,y=1,kind='scatter')
plt.xlabel("Height")
plt.ylabel("RMSE")


# In[314]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




